﻿using UnityEngine;
using System.Collections;

public class StarterScript : MonoBehaviour {

	// Used for initialize the game
	void Start () {
		Application.LoadLevel (1);
	}
}
